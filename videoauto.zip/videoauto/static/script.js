const form = document.getElementById("job-form");
const submitBtn = document.getElementById("submit-btn");
const imagesInput = document.getElementById("images");
const preview = document.getElementById("preview");
const statusBox = document.getElementById("status-box");
const statusText = document.getElementById("status-text");
const progressFill = document.getElementById("progress-fill");
const downloadBtn = document.getElementById("download-btn");
const errorBox = document.getElementById("error-box");
const errorText = document.getElementById("error-text");
const retryBtn = document.getElementById("retry-btn");

let pollTimer = null;

imagesInput.addEventListener("change", () => {
  preview.innerHTML = "";
  const files = Array.from(imagesInput.files || []);
  files.forEach((file) => {
    const img = document.createElement("img");
    img.src = URL.createObjectURL(file);
    preview.appendChild(img);
  });
});

function showError(message) {
  errorText.textContent = message;
  errorBox.classList.remove("hidden");
  statusBox.classList.add("hidden");
  submitBtn.disabled = false;
}

function resetUI() {
  errorBox.classList.add("hidden");
  statusBox.classList.remove("hidden");
  downloadBtn.classList.add("hidden");
  progressFill.style.width = "0%";
  statusText.textContent = "Enviando arquivos... (pode levar até 60s se o servidor estava dormindo)";
  submitBtn.disabled = true;
}

retryBtn.addEventListener("click", () => {
  errorBox.classList.add("hidden");
  submitBtn.disabled = false;
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (pollTimer) clearInterval(pollTimer);

  const script = document.getElementById("script").value.trim();
  const files = imagesInput.files;

  if (!script) {
    showError("Cole o roteiro em inglês antes de enviar.");
    return;
  }
  if (!files || files.length === 0) {
    showError("Selecione pelo menos uma foto.");
    return;
  }

  resetUI();

  const formData = new FormData();
  formData.append("script", script);
  for (const file of files) formData.append("images", file);

  try {
    const res = await fetch("/api/jobs", { method: "POST", body: formData });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.detail || `Erro do servidor (${res.status})`);
    }
    const data = await res.json();
    pollStatus(data.job_id);
  } catch (err) {
    showError(err.message || "Falha ao enviar. Verifique sua conexão e tente novamente.");
  }
});

function pollStatus(jobId) {
  pollTimer = setInterval(async () => {
    try {
      const res = await fetch(`/api/jobs/${jobId}`);
      if (!res.ok) {
        clearInterval(pollTimer);
        showError("Não foi possível consultar o status do job.");
        return;
      }
      const job = await res.json();

      if (job.status === "error") {
        clearInterval(pollTimer);
        showError(job.error || "Ocorreu um erro durante o processamento.");
        return;
      }

      progressFill.style.width = `${job.progress || 0}%`;
      statusText.textContent = job.stage || "Processando...";

      if (job.status === "done") {
        clearInterval(pollTimer);
        statusText.textContent = "Vídeo pronto!";
        downloadBtn.href = `/api/jobs/${jobId}/download`;
        downloadBtn.classList.remove("hidden");
        submitBtn.disabled = false;
      }
    } catch (err) {
      // erro de rede pontual: não aborta, tenta de novo no próximo tick
      statusText.textContent = "Reconectando...";
    }
  }, 2000);
}
